<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Electoral</b>
    </div>
    <strong> &copy; 2022 Brought To You By <a href="#">Muskan</a></strong>
</footer>