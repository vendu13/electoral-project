<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>Electoral</b>
      </div>
      <strong> &copy; 2022  To You By <a href="#">Muskan</a></strong>
    </div>
    <!-- /.container -->
</footer>